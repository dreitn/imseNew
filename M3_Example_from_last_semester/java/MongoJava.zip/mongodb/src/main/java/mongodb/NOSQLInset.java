package mongodb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class NOSQLInset {

	public void startInsert() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			String database = "jdbc:mysql://0.0.0.0:3306/crmtool";
			String user = "root";
			String pass = "imse";
			// establish connection to database
			Connection con = DriverManager.getConnection(database, user, pass);
			Statement stmt = con.createStatement();
			System.out.println("Successfully conected to " + database + "!");

			MongoClientURI url = new MongoClientURI("mongodb://admin:imse@localhost:27017");
			MongoClient mongo = new MongoClient(url);
			MongoDatabase databaseMongo = mongo.getDatabase("imse");

			MongoCollection<Document> collection = databaseMongo.getCollection("Shop");

			System.out.println("Migration started!");
			Statement shopStmt = con.createStatement();
			ResultSet rsAllShop = shopStmt.executeQuery("Select * from Shop");
			Statement bikeServiceStmt = con.createStatement();
			while (rsAllShop.next()) {
				Document shopDoc = new Document("_id", rsAllShop.getString("ShopID"))
						.append("Name", rsAllShop.getString("Name")).append("City", rsAllShop.getString("City"));
				int shopID = rsAllShop.getInt("ShopID");

				MongoCollection<Document> bikeCollection = databaseMongo.getCollection("Bike");
				Statement stmtBikes = con.createStatement();
				ResultSet rsAllBikes = stmtBikes.executeQuery("Select * from Bike where Bike.ShopID=" + shopID);
				ArrayList<String> bikeIDArray = new ArrayList<String>();
				while (rsAllBikes.next()) {
					bikeIDArray.add(rsAllBikes.getString("BikeID"));
					Document bikeDoc = new Document("_id", rsAllBikes.getString("BikeID"))
							.append("Price", rsAllBikes.getString("Price"))
							.append("Modelname", rsAllBikes.getString("Modelname"));
					Statement stmtBikeRepaid = con.createStatement();
					ResultSet rsEmployeeRepaird = stmtBikeRepaid
							.executeQuery("Select * from Repairs where Repairs.BikeID=" + rsAllBikes.getInt("BikeID"));
					ArrayList<String> bikeEmployeeIDArray = new ArrayList<String>();
					while (rsEmployeeRepaird.next()) {
						bikeEmployeeIDArray.add(rsEmployeeRepaird.getString("EmployeeID"));
					}
					bikeDoc.append("RepairdByEmployeeIDs", bikeEmployeeIDArray);
					bikeCollection.insertOne(bikeDoc);
					stmtBikeRepaid.close();
					rsEmployeeRepaird.close();
				}

				ResultSet rsBikeService = bikeServiceStmt
						.executeQuery("Select * FROM BikeService WHERE BikeService.ShopID=" + shopID);
				while (rsBikeService.next()) {
					shopDoc.append("BikeService", new Document("AvailablePlace", rsBikeService.getInt("AvailablePlace"))
							.append("Roomsize", rsBikeService.getInt("Roomsize")));
				}
				shopDoc.append("Bikes", bikeIDArray);
				collection.insertOne(shopDoc);
				rsBikeService.close();
				rsAllBikes.close();
				stmtBikes.close();
			}
			bikeServiceStmt.close();
			shopStmt.close();
			rsAllShop.close();

			collection = databaseMongo.getCollection("Employee");
			Statement stmtEmployee = con.createStatement();
			Statement stmtChef = con.createStatement();

			ResultSet employeeRs = stmtEmployee.executeQuery("SELECT * FROM Employee NATURAL JOIN Person");
			while (employeeRs.next()) {
				ResultSet chefResultSet = stmtChef
						.executeQuery("SELECT * FROM Employee Natural Join Person Where Employee.EmployeeID ="
								+ employeeRs.getString("Chief_ID"));
				Document doc = new Document("_id", employeeRs.getString("EmployeeID"))
						.append("Name", employeeRs.getString("Name"))
						.append("Lastname", employeeRs.getString("Lastname"))
						.append("Wage", employeeRs.getString("Wage"))
						.append("Workinghours", employeeRs.getString("Workinghours"))
						.append("ShopID", employeeRs.getString("ShopID"));
				Document chefDoc = new Document();
				while (chefResultSet.next()) {
					chefDoc.append("Name", chefResultSet.getString("Name"))
							.append("Lastname", chefResultSet.getString("Lastname"))
							.append("Wage", chefResultSet.getString("Wage"))
							.append("Workinghours", chefResultSet.getString("Workinghours"))
							.append("ShopID", chefResultSet.getString("ShopID"));
				}
				Statement stmtRepairdBikes = con.createStatement();
				ResultSet repairdBikesRs = stmtRepairdBikes.executeQuery(
						"Select * from Repairs where Repairs.EmployeeID=" + employeeRs.getString("EmployeeID"));
				ArrayList<String> bikeIDArray = new ArrayList<String>();
				while (repairdBikesRs.next()) {
					bikeIDArray.add(repairdBikesRs.getString("BikeID"));
				}
				doc.append("Chef", chefDoc);
				collection.insertOne(doc);

				chefResultSet.close();
				stmtRepairdBikes.close();
				repairdBikesRs.close();
			}

			collection = databaseMongo.getCollection("Customer");
			ResultSet customers = stmt.executeQuery("SELECT * FROM Customer Natural Join Person");
			Statement customerBike = con.createStatement();
			Statement customerAccessories = con.createStatement();
			// Statement employeeCustomerStmt = con.createStatement();
			while (customers.next()) {
				Document doc = new Document("_id", customers.getString("CustomerID"))
						.append("Name", customers.getString("Name")).append("Lastname", customers.getString("Lastname"))
						.append("phonenumber", customers.getString("phonenumber"))
						.append("Discountrate", customers.getString("Discountrate"));
				String customerID = customers.getString("CustomerID");
				ResultSet customerBikesRs = customerBike
						.executeQuery("Select * from Bike Where Bike.CustomerID=" + customerID);
				ArrayList<String> bikes = new ArrayList<String>();
				while (customerBikesRs.next()) {
					String bike = customerBikesRs.getString("BikeID");
					bikes.add(bike);
				}
				doc.append("Bikes", bikes);
				ResultSet customerAccsRs = customerAccessories
						.executeQuery("Select * from Accessories where Accessories.CustomerID=" + customerID);
				ArrayList<Document> accessories = new ArrayList<Document>();
				while (customerAccsRs.next()) {
					Document accessory = new Document("ID", customerAccsRs.getString("ID"))
							.append("Brand", customerAccsRs.getString("Brand"))
							.append("Price", customerAccsRs.getInt("Price"))
							.append("EmployeeID", customerAccsRs.getString("EmployeeID"));
					accessories.add(accessory);
				}
				doc.append("Accessories", accessories);
				collection.insertOne(doc);
				customerAccsRs.close();
				customerBikesRs.close();
			}
			customers.close();
			System.out.println("Migration done!");
			stmt.close();
			con.close();
		} catch (

		ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}