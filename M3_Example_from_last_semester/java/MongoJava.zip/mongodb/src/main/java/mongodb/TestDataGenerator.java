package mongodb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

public class TestDataGenerator {

	public static void main(String args[]) {
		MYSQLInsert();
		NOSQLInset insert = new NOSQLInset();
		insert.startInsert();
	}

	public static void MYSQLInsert() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String database = "jdbc:mysql://0.0.0.0:3306/crmtool";
			String user = "root";
			String pass = "imse";

			// establish connection to database
			Connection con = DriverManager.getConnection(database, user, pass);
			Statement stmt = con.createStatement();
			System.out.println("Successfully conected to " + database + "!");

			try {

				// PERSON INSERT
				String[] name_array = new String[] { "Ilhan", "Miran", "Kivanc", "Goker", "Koray", "Sefa", "Aybars",
						"Samet", "Huseyin", "Saner", "Alex", "Hans", "Christian", "Florian", "Matthias", "Mathias",
						"Franz", "Thomas", "Tina", "Tamara", "Sara", "Lara", "Lena", "Anna", "Sandra", "Veronika",
						"Iris", "Irina", "Laura", "Meryl", "Chantal", "Estrela", "Milena", "Danica", "Irma", "Mel",
						"Lina", "Barbara", "Jul", "Georgia", "Martha", "Magda", "Lisa", "Franka", "Laura", "Marlene",
						"Veronika", "Christina", "Chandler", "Ross", "Luke", "Pheobe", "Pheobo", "Joey", "Chanandler",
						"Jerry", "Kramer", "Ellen", "Jay", "Gloria", "Phil", "Claire", "Samantha", "Donald", "Eric",
						"Charles", "Paul", "Raul", "Gareth", "Alex", "Lionel", "Cristiano", "Zlatan", "Zinedine",
						"Thierry", "Henry", "Carmelo", "Jamal", "Karim", "Arnold", "Denise", "Mia", "Tom", "Marlene",
						"Frey" };

				String[] surname_array = new String[] { "Angin", "Erturk", "Mueller", "Schubert", "Wagner", "Pauls",
						"Krensel", "Ozturk", "Mustermann", "Cinel", "Huber", "Schmidt", "Kurz", "Van der Bellen",
						"Haeupl", "Koc", "Koeymen", "Avci", "James", "Ford", "Mert", "Schwarz", "Niedhoff", "Lugner",
						"Sandler", "Depp", "Hemsworth", "Carrel", "Scott", "Zoidberg", "Bing", "Geller", "Buffay",
						"Tribiani", "Green", "Harpert", "Schrute", "Sutcuoglu", "Bryant", "Anthony", "Sinatra",
						"Presley", "Charles", "Malone", "Armstrong", "Lightyear", "Aldrin", "Gagarov", "Obama",
						"Clinton", "Hilton", "Glock", "Johansson", "Lima", "Lee", "Chan", "Cocu", "Aragones", "Zico",
						"Zidane", "Ronaldo", "Messi", "Henry", "Bale", "De Bruyne", "Joshua", "Anthony", "Woods",
						"Jobs", "Wozniak", "Xavier", "Gosling", "Hardy", "Spears", "Jolie", "Khalifa", "Brie", "Kunis",
						"Zamnbrotta", "Kejman", "Dirar", "Ndiaye", "Ziegler", "Linnes", "Jailson", "Souza", "Appiah",
						"Kjaer", "Skrtel", "Isla", "Sow", "Kuyt", "Lens", "Quaresma", "Sneijder", "Hagi", "Drogba",
						"Ibrahimovic", "Benzia", "Deivid", "Ribas", "Valbuena", "Alaba", "Neustaedter", "Mariano",
						"Slimani", "Soldado", "Negredo", "Love", "Babel" };
				String vorname = "";
				String nachname = "";
				String executersql = "";
				for (int i = 0; i < 300; i++) {
					int randomNum = ThreadLocalRandom.current().nextInt(0, name_array.length);
					vorname = name_array[randomNum];
					randomNum = ThreadLocalRandom.current().nextInt(0, surname_array.length);
					nachname = surname_array[randomNum];
					executersql = "INSERT INTO Person (Name,Lastname) VALUES ('" + vorname + "','" + nachname + "' )";
					System.out.println(executersql);
					stmt.executeUpdate(executersql);
				}
				ArrayList person_ID_array = new ArrayList();
				ResultSet rsmitid = stmt.executeQuery("SELECT ID FROM Person");
				while (rsmitid.next()) {
					person_ID_array.add(rsmitid.getInt(1));
				}
				rsmitid.close();

				// SHOP INSERT
				String[] shop_array = new String[] { "Sinatra", "Presley", "Lennon", "Mccartney", "Harrison", "Starr",
						"Armstrong", "Cash", "Charles", "Mercury" };
				String[] city_array = new String[] { "WIEN", "GRAZ", "LINZ", "INNSBRUCK", "BREGENZ" };
				for (int i = 0; i <= 9; i++) {
					int randomort = ThreadLocalRandom.current().nextInt(0, 5);
					executersql = "INSERT INTO Shop (Name,CITY) VALUES ('" + shop_array[i] + "','"
							+ city_array[randomort] + "')";
					stmt.executeUpdate(executersql);
					System.out.println(executersql);
				}
				ArrayList shop_ID_array = new ArrayList();
				ResultSet rsshopid = stmt.executeQuery("SELECT ShopID FROM Shop");
				while (rsshopid.next()) {
					shop_ID_array.add(rsshopid.getInt(1));
				}
				rsshopid.close();
				// BIKESERVICE INSERT
				Vector<Integer> availableplace = new Vector<Integer>();
				for (int i = 1; i <= 10; i++) {
					int random_available = ThreadLocalRandom.current().nextInt(1, 30);
					executersql = "INSERT INTO BikeService VALUES(" + i + "," + random_available + ","
							+ ThreadLocalRandom.current().nextInt(50, 120) + "," + i + ")";
					stmt.executeUpdate(executersql);
					System.out.println(executersql);
					availableplace.add(random_available);
				}
				ArrayList bikeservice_ID_array = new ArrayList();
				ResultSet rsbsid = stmt.executeQuery("SELECT ServiceID FROM BikeService");
				while (rsbsid.next()) {
					bikeservice_ID_array.add(rsbsid.getInt(1));
				}
				rsbsid.close();

				// Employee INSERT
				for (int i = 1; i <= person_ID_array.size() / 3; i++) {
					int randomhours = ThreadLocalRandom.current().nextInt(25, 40);
					int randomnumshop = ThreadLocalRandom.current().nextInt(1, 11);
					int randomwage = ThreadLocalRandom.current().nextInt(1000, 2000);
					if (i <= 10) {
						executersql = "INSERT INTO Employee( WAGE, WORKINGHOURS, ID, SHOPID, CHIEF_ID)VALUES("
								+ randomwage + "," + randomhours + "," + i + "," + randomnumshop + "," + i + ")";
						stmt.executeUpdate(executersql);
						System.out.println(executersql);
					}
					if (i > 10) {
						executersql = "INSERT INTO Employee( WAGE, WORKINGHOURS, ID, SHOPID, CHIEF_ID)VALUES("
								+ randomwage + "," + randomhours + "," + i + "," + randomnumshop + "," + randomnumshop
								+ ")";
						stmt.executeUpdate(executersql);
						System.out.println(executersql);
					}
				}

				ArrayList employeeIdArray = new ArrayList();
				ResultSet rsempid = stmt.executeQuery("SELECT EmployeeID FROM Employee");
				while (rsempid.next()) {
					employeeIdArray.add(rsempid.getInt(1));
				}
				rsempid.close();

				// Customer INSERT
				String randomphonenumber = "";
				ArrayList<String> discountrate_list = new ArrayList<String>(
						Arrays.asList("%0", "%10", "%15", "%20", "%25"));
				for (int i = employeeIdArray.size() + 1; i <= person_ID_array.size(); i++) {
					for (int x = 0; x < 15; x++) {
						randomphonenumber = randomphonenumber + ThreadLocalRandom.current().nextInt(0, 10);
					}
					executersql = "INSERT INTO Customer(phonenumber,Discountrate,ID) VALUES(" + randomphonenumber + ",'"
							+ discountrate_list.get(ThreadLocalRandom.current().nextInt(0, 5)) + "'," + i + ")";
					stmt.executeUpdate(executersql);
					System.out.println(executersql);
					randomphonenumber = "";
				}
				ArrayList customerIdArray = new ArrayList();
				ResultSet rscusid = stmt.executeQuery("SELECT CustomerID FROM Customer");
				while (rscusid.next()) {
					customerIdArray.add(rscusid.getInt(1));
				}
				rscusid.close();
				// ACCESSORIES INSERT
				int randomprice = 0;
				for (int i = 0; i < 1000; i++) {
					randomprice = ThreadLocalRandom.current().nextInt(2, 50);
					executersql = "INSERT INTO Accessories(Brand,Price,CustomerID,EmployeeID) VALUES(" + "'ilobikes'"
							+ "," + randomprice + ","
							+ customerIdArray.get(ThreadLocalRandom.current().nextInt(0, customerIdArray.size())) + ","
							+ employeeIdArray.get((ThreadLocalRandom.current().nextInt(0, employeeIdArray.size())))
							+ ")";
					stmt.executeUpdate(executersql);
					System.out.println(executersql);
					randomprice = ThreadLocalRandom.current().nextInt(2, 50);
					executersql = "INSERT INTO Accessories(Brand,Price,CustomerID,EmployeeID) VALUES("
							+ "'sportsdirect'" + "," + randomprice + ","
							+ customerIdArray.get(ThreadLocalRandom.current().nextInt(0, customerIdArray.size())) + ","
							+ employeeIdArray.get((ThreadLocalRandom.current().nextInt(0, employeeIdArray.size())))
							+ ")";
					System.out.println(executersql);
					randomprice = ThreadLocalRandom.current().nextInt(2, 50);
					executersql = "INSERT INTO Accessories(Brand,Price,CustomerID,EmployeeID) VALUES(" + "'Rauchbauer'"
							+ "," + randomprice + ","
							+ customerIdArray.get(ThreadLocalRandom.current().nextInt(0, customerIdArray.size())) + ","
							+ employeeIdArray.get((ThreadLocalRandom.current().nextInt(0, employeeIdArray.size())))
							+ ")";
					stmt.executeUpdate(executersql);
					System.out.println(executersql);
				}
				// Bike INSERT
				String[] modelname_list = new String[] { "X", "Y", "Z", "CRAZY", "UNICORN", "AMAZING", "BIKCHES",
						"THEY SEE ME ROLLIN", "THEY HATIN", "THEY TRYN CATCH ME", "RIDIN DIRTY", "ICE T", "E-LO",
						"CHI-LO", "T-BONE", "COOLIO" };
				for (int i = 0; i < 150; i++) {
					String modelname = modelname_list[ThreadLocalRandom.current().nextInt(0, modelname_list.length)];
					int randomShopSelector = ThreadLocalRandom.current().nextInt(1, 11);
					executersql = "INSERT INTO Bike(CustomerID,Price,Modelname,ServiceID,ShopID) VALUES("
							+ customerIdArray.get(ThreadLocalRandom.current().nextInt(1, customerIdArray.size())) + ","
							+ ThreadLocalRandom.current().nextInt(300, 1000) + ",'" + modelname + "',"
							+ randomShopSelector + "," + randomShopSelector + ")";
					stmt.executeUpdate(executersql);
					System.out.println(executersql);
				}
				ArrayList Bike_ID_array = new ArrayList();
				ResultSet rsbikid = stmt.executeQuery("SELECT BikeID FROM Bike");
				while (rsbikid.next()) {
					Bike_ID_array.add(rsbikid.getInt(1));
				}
				rsbikid.close();
				// Repairs Insert
				for (int i = 0; i < 100; i++) {
					int randombikeservice = ThreadLocalRandom.current().nextInt(0, bikeservice_ID_array.size());
					int randomDayLimit = 32;
					int randomYear = ThreadLocalRandom.current().nextInt(1901, 2020);
					int randomMonth = ThreadLocalRandom.current().nextInt(1, 13);
					if (randomMonth == 2)
						randomDayLimit = 28;
					if (randomMonth == 4 || randomMonth == 6 || randomMonth == 9 || randomMonth == 11)
						randomDayLimit = 31;
					int randomDay = ThreadLocalRandom.current().nextInt(1, randomDayLimit);
					String date = randomYear + "-" + randomMonth + "-" + randomDay;
					executersql = "INSERT INTO Repairs VALUES (" + Bike_ID_array.get(i) + ","
							+ employeeIdArray.get(ThreadLocalRandom.current().nextInt(1, employeeIdArray.size())) + ",'"
							+ date + "')";
					stmt.executeUpdate(executersql);
					System.out.println(executersql);
				}
			} catch (

			Exception e) {
				System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
			}

			stmt.close();
			con.close();

		} catch (

		Exception e) {
			System.err.println(e.getMessage());

		}
	}
}
